self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "9dcd3602c64859970fea19e7dde314e7",
    "url": "https://louiscklaw.github.io/test-react-pwa/index.html"
  },
  {
    "revision": "e2a9f573c49d1e20eaba",
    "url": "https://louiscklaw.github.io/test-react-pwa/static/css/main.5ecd60fb.chunk.css"
  },
  {
    "revision": "382f195a15e83793628f",
    "url": "https://louiscklaw.github.io/test-react-pwa/static/js/2.4f894669.chunk.js"
  },
  {
    "revision": "e88a3e95b5364d46e95b35ae8c0dc27d",
    "url": "https://louiscklaw.github.io/test-react-pwa/static/js/2.4f894669.chunk.js.LICENSE.txt"
  },
  {
    "revision": "e2a9f573c49d1e20eaba",
    "url": "https://louiscklaw.github.io/test-react-pwa/static/js/main.d7aed570.chunk.js"
  },
  {
    "revision": "4541cdfdbace1880078a",
    "url": "https://louiscklaw.github.io/test-react-pwa/static/js/runtime-main.4b1b87ae.js"
  }
]);